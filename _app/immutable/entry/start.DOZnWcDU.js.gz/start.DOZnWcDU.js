import{a as t}from"../chunks/entry.C4ljBf6f.js";export{t as start};
