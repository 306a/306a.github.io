import{a as t}from"../chunks/entry.telc4iZA.js";export{t as start};
