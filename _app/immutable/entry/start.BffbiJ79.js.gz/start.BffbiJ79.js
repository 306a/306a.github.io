import{a as t}from"../chunks/entry.C59k0HNF.js";export{t as start};
