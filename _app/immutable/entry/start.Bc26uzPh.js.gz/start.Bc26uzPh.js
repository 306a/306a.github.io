import{a as t}from"../chunks/entry.CIvKw9_4.js";export{t as start};
