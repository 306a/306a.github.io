import{a as t}from"../chunks/entry.BA6y4Mmq.js";export{t as start};
