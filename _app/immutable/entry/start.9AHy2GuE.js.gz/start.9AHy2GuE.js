import{a as t}from"../chunks/entry.BJ6eZ7-r.js";export{t as start};
