import{a as t}from"../chunks/entry.33_p7cng.js";export{t as start};
