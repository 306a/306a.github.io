import{a as t}from"../chunks/entry.YH--dOA0.js";export{t as start};
