import{a as t}from"../chunks/entry.DRXitlJl.js";export{t as start};
