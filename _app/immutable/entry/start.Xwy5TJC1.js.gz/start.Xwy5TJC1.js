import{a as t}from"../chunks/entry.45kYc78J.js";export{t as start};
