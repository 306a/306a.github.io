import{a as t}from"../chunks/entry.B2YwPjiq.js";export{t as start};
