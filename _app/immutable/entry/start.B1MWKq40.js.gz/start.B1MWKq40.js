import{a as t}from"../chunks/entry.CCOAM8hu.js";export{t as start};
