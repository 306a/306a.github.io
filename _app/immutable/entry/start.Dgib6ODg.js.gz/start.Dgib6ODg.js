import{a as t}from"../chunks/entry.BLKFm5pU.js";export{t as start};
