import{a as t}from"../chunks/entry.CrfRy67g.js";export{t as start};
