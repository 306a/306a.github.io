import{a as t}from"../chunks/entry.Dhhx9dcM.js";export{t as start};
