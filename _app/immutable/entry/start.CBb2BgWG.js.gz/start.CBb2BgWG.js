import{a as t}from"../chunks/entry.BxMDTez_.js";export{t as start};
