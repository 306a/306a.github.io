import{a as t}from"../chunks/entry.BbqfEzf4.js";export{t as start};
